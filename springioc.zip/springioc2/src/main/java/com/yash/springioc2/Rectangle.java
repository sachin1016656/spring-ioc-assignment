package com.yash.springioc2;

public class Rectangle extends Shape {

	float Area,width,length;
	@Override
	public void draw() {
		Area=width*length;
		System.out.println(Area);
	}
	public float getArea() {
		return Area;
	}
	public void setArea(float area) {
		Area = area;
	}
	public float getWidth() {
		return width;
	}
	public void setWidth(float width) {
		this.width = width;
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public Rectangle(float area, float width, float length) {
		super();
		Area = area;
		this.width = width;
		this.length = length;
	}
	public Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Rectangle [Area=" + Area + ", width=" + width + ", length=" + length + "]";
	}
	

}
