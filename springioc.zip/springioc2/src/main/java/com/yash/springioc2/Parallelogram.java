package com.yash.springioc2;

public class Parallelogram extends Shape {

	float Area,base,height;
	@Override
	public void draw() {
		
		Area=base*height;
		System.out.println(Area);
	}
	public float getArea() {
		return Area;
	}
	public void setArea(float area) {
		Area = area;
	}
	public float getBase() {
		return base;
	}
	public void setBase(float base) {
		this.base = base;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	public Parallelogram(float area, float base, float height) {
		super();
		Area = area;
		this.base = base;
		this.height = height;
	}
	public Parallelogram() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Parallelogram [Area=" + Area + ", base=" + base + ", height=" + height + "]";
	}
	

}
