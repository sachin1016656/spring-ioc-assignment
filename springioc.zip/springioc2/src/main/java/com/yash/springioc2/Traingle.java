package com.yash.springioc2;

public class Traingle extends Shape{
     
	public Traingle(float area, float base, float height) {
		super();
		Area = area;
		this.base = base;
		this.height = height;
	}
	public float getArea() {
		return Area;
	}
	public void setArea(float area) {
		Area = area;
	}
	public float getBase() {
		return base;
	}
	public void setBase(float base) {
		this.base = base;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	public Traingle() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public String toString() {
		return "Traingle [Area=" + Area + ", base=" + base + ", height=" + height + "]";
	}


	float Area,base,height;
	@Override
	public void draw() {
		
		Area=(base*height)/2;
		System.out.println(Area);
	}

}
