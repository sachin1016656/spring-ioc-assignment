package com.yash.springioc5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	
   public static Employee getEmployee() {
	//return new Clerk();
	//return new Manager();
	return new Supervisor();
   
   }
}
