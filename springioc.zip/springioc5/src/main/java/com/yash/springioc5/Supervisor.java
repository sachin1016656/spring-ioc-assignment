package com.yash.springioc5;

public class Supervisor implements Employee {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("hii this is Supervisor");
	}

	
}
