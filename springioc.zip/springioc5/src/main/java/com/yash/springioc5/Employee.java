package com.yash.springioc5;

public interface Employee {

	public void show();

}
