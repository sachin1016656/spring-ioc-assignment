package com.yash.springioc4;

public class SetterMessage {
	
	private String message=null;

	public void setMessage(String message) {
		this.message = message;
	}
	
	public void display() {
		System.out.println(message);
	}
	

}
