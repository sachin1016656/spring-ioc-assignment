package com.yash.spring_ioc;

import java.util.List;

public class Movie {
	
	private List<String> movie_Name;
	private List<String> movie_Timing;
	
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Movie(List<String> movie_Name, List<String> movie_Timing) {
		super();
		this.movie_Name = movie_Name;
		this.movie_Timing = movie_Timing;
	}
	@Override
	public String toString() {
		return "Movie [movie_Name=" + movie_Name + ", movie_Timing=" + movie_Timing + "]";
	}
	public List<String> getMovie_Name() {
		return movie_Name;
	}
	public void setMovie_Name(List<String> movie_Name) {
		this.movie_Name = movie_Name;
	}
	public List<String> getMovie_Timing() {
		return movie_Timing;
	}
	public void setMovie_Timing(List<String> movie_Timing) {
		this.movie_Timing = movie_Timing;
	}
	
	

}
