package com.yash.springioc6;

public class Vehicle {
	
	private String vehicle_Name;
	private String vehicle_Type;
	private Engine engine;
	private double vehicle_Mileage,price;
	
	public String getVehicle_Name() {
		return vehicle_Name;
	}
	public void setVehicle_Name(String vehicle_Name) {
		this.vehicle_Name = vehicle_Name;
	}
	public String getVehicle_Type() {
		return vehicle_Type;
	}
	public void setVehicle_Type(String vehicle_Type) {
		this.vehicle_Type = vehicle_Type;
	}
	public Engine getEngine() {
		return engine;
	}
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	public double getVehicle_Mileage() {
		return vehicle_Mileage;
	}
	public void setVehicle_Mileage(double vehicle_Mileage) {
		this.vehicle_Mileage = vehicle_Mileage;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicle_Name=" + vehicle_Name + ", vehicle_Type=" + vehicle_Type + ", engine=" + engine
				+ ", vehicle_Mileage=" + vehicle_Mileage + ", price=" + price + "]";
	}
	public Vehicle(String vehicle_Name, String vehicle_Type, Engine engine, double vehicle_Mileage, double price) {
		super();
		this.vehicle_Name = vehicle_Name;
		this.vehicle_Type = vehicle_Type;
		this.engine = engine;
		this.vehicle_Mileage = vehicle_Mileage;
		this.price = price;
	}
	public Vehicle() {
		super();
		
	}
	
	public void display() {
		System.out.println("Vehicle Name:    " +vehicle_Name);
		System.out.println("vehicle_Type:    "+vehicle_Type);
		System.out.println("vehicle_Mileage: "+vehicle_Mileage+" kmph");
		System.out.println("price:           "+price+" Rs");
		System.out.println("Engine_Name:     "+engine.getEngine_Name());
		System.out.println("Engine_Power:    "+engine.getEngine_Power());
		System.out.println("Engine_Type:     "+engine.getEngine_Type());
		
	}

	
}
