package com.yash.springioc6;

public class Engine {
	
	private String engine_Type,engine_Name;
	private double  engine_Power;
	public String getEngine_Type() {
		return engine_Type;
	}
	public void setEngine_Type(String engine_Type) {
		this.engine_Type = engine_Type;
	}
	public String getEngine_Name() {
		return engine_Name;
	}
	public void setEngine_Name(String engine_Name) {
		this.engine_Name = engine_Name;
	}
	public double getEngine_Power() {
		return engine_Power;
	}
	public void setEngine_Power(double engine_Power) {
		this.engine_Power = engine_Power;
	}
	@Override
	public String toString() {
		return "Engine [engine_Type=" + engine_Type + ", engine_Name=" + engine_Name + ", engine_Power=" + engine_Power
				+ "]";
	}
	public Engine(String engine_Type, String engine_Name, double engine_Power) {
		super();
		this.engine_Type = engine_Type;
		this.engine_Name = engine_Name;
		this.engine_Power = engine_Power;
	}
	public Engine() {
		super();
		
	}
	
	
}
